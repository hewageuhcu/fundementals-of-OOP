public class one_b {
    public static void main(String[] args) {
        float x = 45.71f;
        int y = (int) x;
        System.out.println("Value of x ="+x);
        System.out.println("Value of y="+y);
    }
}
