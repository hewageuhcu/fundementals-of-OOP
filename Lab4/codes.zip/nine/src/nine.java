import java.util.Scanner;
public class nine{
public static void main (String Args[]){
int netSal=(8000*4)/100+500;
System.out.println("Net salary is "+(netSal));
}
}