public class seven{
    public static void main (String args[]){
        int Y= 19/3*5+2+5/2%7;
        System.out.println("Y is "+Y);
        Y= (19/3+3%2) +5-(5*2+3-2);
        System.out.println("Y is "+Y);
    }
}