public class two{
    public static void main (String args[]){
        int a=42;
        int b=36;
        int quo=a/b;
        int rem=a%b;
        System.out.println(rem);
        System.out.println(quo);
    }
}