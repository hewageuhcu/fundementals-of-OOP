public class one_a{
    public static void main (String args[]){
        int a;
        double d=190.5;
        System.out.println(a=65/7);
        System.out.println(a=65%7+6*5-7);
        System.out.println(a=65+63%6*(13*7%3));
        System.out.println(a+=13);
        System.out.println(a%=3/a+3);
        System.out.println(d+=1.3*5+(++a));
        System.out.println(d-=1.53*3.1-a++);
        System.out.println(d*=2*3+a++);
    }
}